const Web3 = require ('web3');
const Accounts = require('web3-eth-accounts');

const accounts = new Accounts('ws://127.0.0.1:4030');
const web3 = new Web3(new Web3.providers.HttpProvider(`https://rinkeby.infura.io/v3/${process.env.INFURA_PROJECT_ID}`));

exports.get_new_address = async function (req,res) {
    let ethData = {};
    try {
        ethData = await web3.eth.accounts.create();
                  console.table(ethData);
                  ethData.result = ethData.address;
                  return ethData.result;
        } catch(err) {
            ethData.result = err.message
            console.log ( chalk.red ( "REQUEST ERROR" ) );
            return ethData.result;
     }
     console.log(ethData.result);
     return ethData.result;
}

exports.eth_deposit = async function(req, res) {

	const web3_2= new Web3('http://127.0.0.1:7545');

	//Insert other address and private key of a local Ganache account 
	const address = '';
	const privateKey = '';
	
	//Insert other, newly created address
	const receiver = '';
	
	console.log('Sending a transaction ...');
	
	const createTransaction = await web3_2.eth.accounts.signTransaction({
		from: address,
		to: receiver,
		value: web3_2.utils.toWei('2', 'ether'),
		gas: 21000,
	},
	privateKey
	);

	
	const receipt = await web3_2.eth.sendSignedTransaction(createTransaction.rawTransaction);
	console.log('Transaction successful');
}

exports.eth_withdraw = async function(req, res) {
	const web3_3= new Web3('http://127.0.0.1:7545');

	//Insert other address and private key of a newly created account 
	const address = '';
	const privateKey = '';                    
	
	//Insert other address from a local Ganache account
	const receiver = '';

	console.log('Sending a transaction ...');
	
	const createTransaction = await web3_3.eth.accounts.signTransaction({
		from: address,
		to: receiver,
		value: web3.utils.toWei('1', 'ether'),
		gas: 21000,
	},
	privateKey
	);
	
	const receipt = await web3_3.eth.sendSignedTransaction(createTransaction.rawTransaction);
	console.log('Transaction successful');