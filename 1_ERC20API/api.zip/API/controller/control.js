const database = require('../database/dataconnection');
const web3 = require('../web3/index')
const model = require('../models/model');
 const signin = async (req,res)=>{

        const email = req.body.email;
        const password = req.body.password;

      const check =  await  model.findOne({email:email,password:password});
      console.log(check);
       
        if(check)
            res.redirect('/accounts_connection');
        else
        {
            res.status(400).send(`<h1 style="color: red;">credential not matched</h1>`)
        }

    


}

const account_connection = async (req,res)=>{
   
  address = await web3.main();
    res.send(address);
   
}

const mint_token = async (req,res) =>{
    balance = await web3.mint(req.body.amount);
    console.log(balance);
    res.send(balance)
}

const checkbalance = async (req,res) =>{
    balance = await web3.check_balance();
    console.log(balance);
    res.send();
}

const approve = async (req,res) =>{
    const to = (req.body.to).toString();
    
    const value = (req.body.value).toString();
    const approved = await web3.approval(to,value);
    if(approved){
        res.send("approved").status(200);
    }
    else
    res.send("not approved");
    
}

const transfered = async (req,res)=>{
    const to = (req.body.to).toString();
    const from = (req.body.from).toString();
    const value = (req.body.value).toString(); 
    const transfering = await web3.transferFrom(to,from,value);
    res.send(transfering);
    return transfering ;
}

module.exports = {signin ,account_connection,mint_token,checkbalance,approve,transfered};