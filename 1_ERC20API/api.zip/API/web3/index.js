const Web3 = require('web3');
const web3 = new Web3(Web3.givenProvider || 'http://127.0.0.1:7545')
const conf = require('../../build/contracts/Making_token.json')
const contract_Address = conf.networks['5777'].address;
const contract_ABI = conf.abi;
const deploying = new web3.eth.Contract(contract_ABI,contract_Address);
const main = async ()=>{
   // const accounts = await web3.eth.accounts.create();
    address = await web3.eth.accounts.create();
                  console.table(address);
                  console.log(address);
}
const mint = async (address)=>{
    const balance = await deploying.methods.mint(address).send({from:`0x9a982b21FD9e29c05eBeeEe9b7Ad83d04918f8A3`});
    return balance;
}

const check_balance = async ()=>{
    const balance = await deploying.methods.balanceOf('0x9a982b21FD9e29c05eBeeEe9b7Ad83d04918f8A3').call({from:'0xE82A1BA1aad246f9c2D0958CB15B2713c89683d2'});
    return balance;
}

const approval = async (_to , _value) =>{
    const approved = await deploying.methods.approve(_to,_value).send({from:'0x9a982b21FD9e29c05eBeeEe9b7Ad83d04918f8A3'});
    return approved;
}

const transferFrom = async (_to ,_from, _value) =>{
    const transfered = await deploying.methods.transferFrom(_to,_from,_value).send({from:'0x9a982b21FD9e29c05eBeeEe9b7Ad83d04918f8A3'});
    return transfered;
}

module .exports={main,mint,check_balance,approval,transferFrom};